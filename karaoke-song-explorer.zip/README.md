# karaoke-song-explorer
Karaoke Song Explorer is a web application that lets you search for songs featured in 287 karaoke games across multiple platforms: PlayStation, Xbox, Wii, Wii U, and Switch.
